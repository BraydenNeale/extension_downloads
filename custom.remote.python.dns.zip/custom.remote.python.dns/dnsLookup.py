from ruxit.api.base_plugin import RemoteBasePlugin
import requests
import time
import logging
import socket
import dns.resolver

logger = logging.getLogger(__name__)

class CustomDNSPluginRemote(RemoteBasePlugin):

    pollCount = 1
    
    def query(self, **kwargs):
        # Configuration items
        config = kwargs['config']
        hostToTest = config["hostToTest"].strip()
        dnsServer = config["dnsServer"].strip()
        deviceName = config["deviceName"].strip()
        apiURL = config["apiURL"].strip()
        apiToken = config["apiToken"].strip()
        location = config["location"].strip()
        pollingInterval = config["pollingInterval"]
        syntheticEngineName = "DNS lookup"
        if self.pollCount < pollingInterval:
            self.pollCount += 1
            return
            
        self.pollCount = 1
        
        # Make sure that the API URL ends with a slash
        if not apiURL.endswith('/'):
            apiURL += "/"
        
        # Make sure that the API URL starts with https://
        if not apiURL.startswith('http'):
            apiURL = "https://" + apiURL
        
        # Get the name of the server performing the tests
        locationName = socket.gethostname()
        if location != "":
            locationName = location

        # Get the time that the tests are performed
        executionTime = int(time.time()) * 1000

        # Perform the dns test
        successful = True
        res = dns.resolver.Resolver(configure=False)
        res.nameservers = [dnsServer]
        res.lifetime = res.timeout = 2
        starttime = time.time()
        try:
            answers = res.query(hostToTest, "A")
        except Exception as e:
            logger.exception(e)
            successful = False
        if successful:
            responseTime = int((time.time() - starttime)*100)/100

        # Create the Synthetic test post body
        synthetic = {
          "syntheticEngineName": "DNS lookup",
          "messageTimestamp": executionTime,
          "locations": [
            {
              "id": locationName,
              "name": locationName,
              "ip": socket.gethostbyname(socket.gethostname())
            }
          ],
          "tests": [
            {
              "id": deviceName,
              "title": deviceName,
              "editLink": "#settings;gf=all/customextension;id=custom.remote.python.dns;gf=all",
              "locations": [
                {
                  "id": locationName,
                  "enabled": True
                }
              ],
              "noDataTimeout": pollingInterval * 60 + 300,
              "scheduleIntervalInSeconds": pollingInterval * 60
            }
          ],
          "testResults": [
            {
              "id": deviceName,
              "totalStepCount": 0,
              "locationResults": [
                {
                  "id": locationName,
                  "startTimestamp": executionTime,
                  "success": successful
                }
              ]
            }
          ]
        }

        # Only set the response time if the test was successful
        if successful:
            synthetic["testResults"][0]["locationResults"][0]["responseTimeMillis"] = responseTime
            logger.info(f"{deviceName} ({hostToTest} using {dnsServer}) replied in {responseTime}ms")
        else:
            logger.info(f"{deviceName} ({hostToTest} using {dnsServer}) did not reply")
            sysTime = int(round(time.time() * 1000))
            outage = {
              "syntheticEngineName": syntheticEngineName,
              "open": [
                {
                  "testId": deviceName,
                  "eventId": str(sysTime) + deviceName,
                  "name": syntheticEngineName + " outage",
                  "eventType": "testOutage",
                  "reason": f"{deviceName} ({hostToTest} using {dnsServer}) did not reply",
                  "locationIds": [
                    locationName
                  ],
                  "startTimestamp": sysTime
                }
              ]
            }
            # Post the data
            response = requests.post(f"{apiURL}api/v1/synthetic/ext/events?api-token={apiToken}", json=outage, verify=False)

            logger.info(f"Create event {deviceName} ({hostToTest}) status code: {response.status_code}")
            # Status code 204 means it was successful, if it is anything else, log the error
            if response.status_code != 204:
                logger.error(response.text)
            
        # Post the data
        response = requests.post(f"{apiURL}api/v1/synthetic/ext/tests?api-token={apiToken}", json=synthetic, verify=False)

        logger.info(f"{deviceName} ({hostToTest}) status code: {response.status_code}")
        # Status code 204 means it was successful, if it is anything else, log the error
        if response.status_code != 204:
            logger.error(response.text)